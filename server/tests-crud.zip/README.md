# About
App for performing synthetic test CRUD operations

# Sample Git Text for Co-Authoring a Commit in CLI
git commit -m "short informative message

Co-authored-by: Katarina Rosiak <katarinarosiak@gmail.com>
Co-authored-by: Tim Dronkers <tdronkers@gmail.com>
Co-authored-by: Scott Graham <scttgrhm7+public@gmail.com>
Co-authored-by: Miles Abbason <miles.abbason@gmail.com>"