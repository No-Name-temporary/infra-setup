DROP TABLE assertion_results;

DROP TABLE assertions;

DROP TABLE comparison_types;

DROP TABLE tests_regions;

DROP TABLE test_runs;

DROP TABLE regions;

DROP TABLE tests_alerts;

DROP TABLE alerts;

DROP TABLE notification_settings;

DROP TABLE tests;

DROP TABLE http_methods;

DROP TABLE assertion_types;
