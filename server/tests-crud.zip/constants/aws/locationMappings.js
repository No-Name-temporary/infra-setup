module.exports.RULE_TARGET_INFO = {
  'test-route-packager': {
    arn: 'arn:aws:lambda:us-east-1:082057163641:function:test-route-packager',
    title: 'test-route-packager',
  },
};
