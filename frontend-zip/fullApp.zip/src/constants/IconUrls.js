export const GREEN_CHECK_MARK = 'https://img.icons8.com/color/344/checked--v1.png';
export const RED_X = 'https://img.icons8.com/color/344/cancel--v1.png';
export const GARBAGE_CAN = 'https://img.icons8.com/external-others-iconmarket/344/external-delete-essential-others-iconmarket-3.png';
export const PENCIL = 'https://img.icons8.com/ios/2x/edit.png';
export const LIGHTNING = 'https://img.icons8.com/ios/2x/lightning-bolt.png';
export const SMILEY = 'https://img.icons8.com/ios/344/lol--v1.png';
export const STOPWATCH = 'https://img.icons8.com/pastel-glyph/2x/sport-stopwatch.png';
