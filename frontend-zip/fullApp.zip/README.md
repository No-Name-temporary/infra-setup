# tests-ui

The page is publicly available under this link: http://bucket-for-react-app.s3-website-us-east-1.amazonaws.com/ 

# paths
* `/tests`: view all tests
* `/tests/new`: create a new test
* `/tests/:id/runs`: view all runs for a given test
* `/tests/:id/runs/:id`: view the details of a single run for a given test
